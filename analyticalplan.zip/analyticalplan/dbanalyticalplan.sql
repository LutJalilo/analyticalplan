-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema dbanalyticalplan
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema dbanalyticalplan
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `dbanalyticalplan` DEFAULT CHARACTER SET utf8 ;
USE `dbanalyticalplan` ;

-- -----------------------------------------------------
-- Table `dbanalyticalplan`.`faculdade`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dbanalyticalplan`.`faculdade` (
  `codigo_faculdade` INT NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(100) NULL,
  `email` VARCHAR(50) NULL,
  `endereco` VARCHAR(50) NULL,
  `cidade` VARCHAR(50) NULL,
  `telefone` VARCHAR(9) NULL,
  `fax` VARCHAR(9) NULL,
  PRIMARY KEY (`codigo_faculdade`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `dbanalyticalplan`.`curso`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dbanalyticalplan`.`curso` (
  `codigo_curso` INT NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(100) NULL,
  `grau_academico` VARCHAR(50) NULL,
  `duracao` VARCHAR(50) NULL,
  `faculdade_codigo` INT NOT NULL,
  PRIMARY KEY (`codigo_curso`),
  INDEX `fk_curso_faculdade_idx` (`faculdade_codigo` ASC) VISIBLE,
  CONSTRAINT `fk_curso_faculdade`
    FOREIGN KEY (`faculdade_codigo`)
    REFERENCES `dbanalyticalplan`.`faculdade` (`codigo_faculdade`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `dbanalyticalplan`.`usuario`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dbanalyticalplan`.`usuario` (
  `codigo_usuario` INT NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(100) NULL,
  `email` VARCHAR(50) NULL,
  `genero` VARCHAR(50) NULL,
  `senha` VARCHAR(50) NULL,
  `tipo` VARCHAR(50) NULL,
  `telefone` VARCHAR(9) NULL,
  `cidade` VARCHAR(50) NULL,
  `endereco` VARCHAR(50) NULL,
  PRIMARY KEY (`codigo_usuario`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `dbanalyticalplan`.`disciplina`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dbanalyticalplan`.`disciplina` (
  `codigo_disciplina` INT NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(100) NULL,
  `tipo_disciplina` VARCHAR(50) NULL,
  `semestre` VARCHAR(50) NULL,
  `creditos` VARCHAR(50) NULL,
  `ano_frequencia` VARCHAR(50) NULL,
  `objectivos_disciplina` TEXT NULL,
  `curso_codigo` INT NOT NULL,
  `usuario_codigo` INT NOT NULL,
  PRIMARY KEY (`codigo_disciplina`),
  INDEX `fk_disciplina_curso1_idx` (`curso_codigo` ASC) VISIBLE,
  INDEX `fk_disciplina_usuario1_idx` (`usuario_codigo` ASC) VISIBLE,
  CONSTRAINT `fk_disciplina_curso1`
    FOREIGN KEY (`curso_codigo`)
    REFERENCES `dbanalyticalplan`.`curso` (`codigo_curso`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_disciplina_usuario1`
    FOREIGN KEY (`usuario_codigo`)
    REFERENCES `dbanalyticalplan`.`usuario` (`codigo_usuario`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `dbanalyticalplan`.`plano_analitico`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dbanalyticalplan`.`plano_analitico` (
  `codigo_plano_analitico` INT NOT NULL AUTO_INCREMENT,
  `data_inicial` DATE NULL,
  `data_final` DATE NULL,
  `conteudo` TEXT NULL,
  `objectivos` TEXT NULL,
  `actividades` TEXT NULL,
  `bibliografia` TEXT NULL,
  `disciplina_codigo` INT NOT NULL,
  PRIMARY KEY (`codigo_plano_analitico`),
  INDEX `fk_plano_analitico_disciplina1_idx` (`disciplina_codigo` ASC) VISIBLE,
  CONSTRAINT `fk_plano_analitico_disciplina1`
    FOREIGN KEY (`disciplina_codigo`)
    REFERENCES `dbanalyticalplan`.`disciplina` (`codigo_disciplina`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `dbanalyticalplan`.`faculdade_usuario`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `dbanalyticalplan`.`faculdade_usuario` (
  `faculdade_codigo` INT NOT NULL,
  `usuario_codigo` INT NOT NULL,
  PRIMARY KEY (`faculdade_codigo`, `usuario_codigo`),
  INDEX `fk_faculdade_has_usuario_usuario1_idx` (`usuario_codigo` ASC) VISIBLE,
  INDEX `fk_faculdade_has_usuario_faculdade1_idx` (`faculdade_codigo` ASC) VISIBLE,
  CONSTRAINT `fk_faculdade_has_usuario_faculdade1`
    FOREIGN KEY (`faculdade_codigo`)
    REFERENCES `dbanalyticalplan`.`faculdade` (`codigo_faculdade`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_faculdade_has_usuario_usuario1`
    FOREIGN KEY (`usuario_codigo`)
    REFERENCES `dbanalyticalplan`.`usuario` (`codigo_usuario`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
