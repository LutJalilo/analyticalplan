package model;

public class Disciplina {
	private String codigo_disciplina;
	private String nome;
	private String tipo_disciplina;
	private String semestre;
	private String creditos;
	private String ano_frequencia;
	private String objectivos_disciplina;
	private Curso curso;
	private Usuario usuario;
	
	public Disciplina() {
		super();
	}

	public Disciplina(String codigo_disciplina, String nome, String tipo_disciplina, String semestre, String creditos,
			String ano_frequencia, String objectivos_disciplina, Curso curso, Usuario usuario) {
		super();
		this.codigo_disciplina = codigo_disciplina;
		this.nome = nome;
		this.tipo_disciplina = tipo_disciplina;
		this.semestre = semestre;
		this.creditos = creditos;
		this.ano_frequencia = ano_frequencia;
		this.objectivos_disciplina = objectivos_disciplina;
		this.curso = curso;
		this.usuario = usuario;
	}

	public String getCodigo_disciplina() {
		return codigo_disciplina;
	}

	public void setCodigo_disciplina(String codigo_disciplina) {
		this.codigo_disciplina = codigo_disciplina;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getTipo_disciplina() {
		return tipo_disciplina;
	}

	public void setTipo_disciplina(String tipo_disciplina) {
		this.tipo_disciplina = tipo_disciplina;
	}

	public String getSemestre() {
		return semestre;
	}

	public void setSemestre(String semestre) {
		this.semestre = semestre;
	}

	public String getCreditos() {
		return creditos;
	}

	public void setCreditos(String creditos) {
		this.creditos = creditos;
	}

	public String getAno_frequencia() {
		return ano_frequencia;
	}

	public void setAno_frequencia(String ano_frequencia) {
		this.ano_frequencia = ano_frequencia;
	}

	public String getObjectivos_disciplina() {
		return objectivos_disciplina;
	}

	public void setObjectivos_disciplina(String objectivos_disciplina) {
		this.objectivos_disciplina = objectivos_disciplina;
	}

	public Curso getCurso() {
		return curso;
	}

	public void setCurso(Curso curso) {
		this.curso = curso;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}
	
}