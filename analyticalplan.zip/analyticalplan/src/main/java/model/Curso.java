package model;

public class Curso {
	private String codigo_curso;
	private String nome;
	private String grau_academico;
	private String duracao;
	private Faculdade faculdade;

	public Curso() {
		super();
	}

	public Curso(String codigo_curso, String nome, String grau_academico, String duracao, Faculdade faculdade) {
		super();
		this.codigo_curso = codigo_curso;
		this.nome = nome;
		this.grau_academico = grau_academico;
		this.duracao = duracao;
		this.faculdade = faculdade;
	}

	public String getCodigo_curso() {
		return codigo_curso;
	}

	public void setCodigo_curso(String codigo_curso) {
		this.codigo_curso = codigo_curso;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getGrau_academico() {
		return grau_academico;
	}

	public void setGrau_academico(String grau_academico) {
		this.grau_academico = grau_academico;
	}

	public String getDuracao() {
		return duracao;
	}

	public void setDuracao(String duracao) {
		this.duracao = duracao;
	}

	public Faculdade getFaculdade() {
		return faculdade;
	}

	public void setFaculdade(Faculdade faculdade) {
		this.faculdade = faculdade;
	}
}