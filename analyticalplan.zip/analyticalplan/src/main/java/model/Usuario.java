package model;

public class Usuario {
	private String codigo_usuario;
	private String nome;
	private String email;
	private String genero;
	private String senha;
	private String tipo;
	private String telefone;
	private String cidade;
	private String endereco;

	public Usuario() {
		super();
	}

	public Usuario(String codigo_usuario, String nome, String email, String genero, String senha, String tipo,
			String telefone, String cidade, String endereco) {
		super();
		this.codigo_usuario = codigo_usuario;
		this.nome = nome;
		this.email = email;
		this.genero = genero;
		this.senha = senha;
		this.tipo = tipo;
		this.telefone = telefone;
		this.cidade = cidade;
		this.endereco = endereco;
	}

	public String getCodigo_usuario() {
		return codigo_usuario;
	}

	public void setCodigo_usuario(String codigo_usuario) {
		this.codigo_usuario = codigo_usuario;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getGenero() {
		return genero;
	}

	public void setGenero(String genero) {
		this.genero = genero;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
}