package model;

public class Plano_Analitico {
	private String codigo_plano_analitico;
	private String semana;
	private String conteudo;
	private String objectivos;
	private String actividades;
	private String bibliografia;
	private Disciplina disciplina;
	
	public Plano_Analitico() {
		super();
	}

	public Plano_Analitico(String codigo_plano_analitico, String semana, String conteudo, String objectivos,
			String actividades, String bibliografia, Disciplina disciplina) {
		super();
		this.codigo_plano_analitico = codigo_plano_analitico;
		this.semana = semana;
		this.conteudo = conteudo;
		this.objectivos = objectivos;
		this.actividades = actividades;
		this.bibliografia = bibliografia;
		this.disciplina = disciplina;
	}

	public String getCodigo_plano_analitico() {
		return codigo_plano_analitico;
	}

	public void setCodigo_plano_analitico(String codigo_plano_analitico) {
		this.codigo_plano_analitico = codigo_plano_analitico;
	}

	public String getSemana() {
		return semana;
	}

	public void setSemana(String semana) {
		this.semana = semana;
	}

	public String getConteudo() {
		return conteudo;
	}

	public void setConteudo(String conteudo) {
		this.conteudo = conteudo;
	}

	public String getObjectivos() {
		return objectivos;
	}

	public void setObjectivos(String objectivos) {
		this.objectivos = objectivos;
	}

	public String getActividades() {
		return actividades;
	}

	public void setActividades(String actividades) {
		this.actividades = actividades;
	}

	public String getBibliografia() {
		return bibliografia;
	}

	public void setBibliografia(String bibliografia) {
		this.bibliografia = bibliografia;
	}

	public Disciplina getDisciplina() {
		return disciplina;
	}

	public void setDisciplina(Disciplina disciplina) {
		this.disciplina = disciplina;
	}
}