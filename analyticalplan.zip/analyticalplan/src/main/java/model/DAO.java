package model;

import java.sql.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class DAO {
	private String url = "jdbc:mysql://127.0.0.1:3306/dbanalyticalplan?";
	private String user = "root";
	private String password = "lut99";

	public Connection Conectar() {
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(url, user, password);
			return con;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	/* CRUD CREATE **/

	public void criarUsuario(Usuario usuario) {
		String insertUsuario = "insert into usuario(nome, email, genero, senha, tipo, telefone, cidade, endereco) values (?, ?, ?, PASSWORD(?), ?, ?, ?, ?)";

		try {
			Connection con = Conectar();

			PreparedStatement pst = con.prepareStatement(insertUsuario);

			pst.setString(1, usuario.getNome());
			pst.setString(2, usuario.getEmail());
			pst.setString(3, usuario.getGenero());
			pst.setString(4, usuario.getSenha());
			pst.setString(5, usuario.getTipo());
			pst.setString(6, usuario.getTelefone());
			pst.setString(7, usuario.getCidade());
			pst.setString(8, usuario.getEndereco());
			pst.executeUpdate();

			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void insertFaculdade(Faculdade faculdade) {
		String insertFaculdade = "insert into faculdade(nome, email, endereco, cidade, telefone, fax) values (?, ?, ?, ?, ?, ?)";

		try {
			Connection con = Conectar();
			PreparedStatement pst = con.prepareStatement(insertFaculdade);
			pst.setString(1, faculdade.getNome());
			pst.setString(2, faculdade.getEmail());
			pst.setString(3, faculdade.getEndereco());
			pst.setString(4, faculdade.getCidade());
			pst.setString(5, faculdade.getTelefone());
			pst.setString(6, faculdade.getFax());
			pst.executeUpdate();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void inserirCurso(Curso curso) {
		String insertCurso = "insert into curso(nome, grau_academico, duracao, faculdade_codigo) values (?, ?, ?, ?)";
		try {
			Connection con = Conectar();
			PreparedStatement pst = con.prepareStatement(insertCurso);
			pst.setString(1, curso.getNome());
			pst.setString(2, curso.getGrau_academico());
			pst.setString(3, curso.getDuracao());
			pst.setString(4, curso.getFaculdade().getCodigo_faculdade());
			pst.executeUpdate();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void inserirDisciplina(Disciplina disciplina) {
		String insertDisciplina = "insert into disciplina (nome, tipo_disciplina, semestre, creditos, ano_frequencia, objectivos_disciplina, curso_codigo, usuario_codigo) values (?, ?, ?, ?, ?, ?, ?, ?)";

		try {
			Connection con = Conectar();
			PreparedStatement pst = con.prepareStatement(insertDisciplina);
			pst.setString(1, disciplina.getNome());
			pst.setString(2, disciplina.getTipo_disciplina());
			pst.setString(3, disciplina.getSemestre());
			pst.setString(4, disciplina.getCreditos());
			pst.setString(5, disciplina.getAno_frequencia());
			pst.setString(6, disciplina.getObjectivos_disciplina());
			pst.setString(7, disciplina.getCurso().getCodigo_curso());
			pst.setString(8, disciplina.getUsuario().getCodigo_usuario());
			pst.executeUpdate();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void inserirPlano_Analitico(Plano_Analitico plano_analitico) {
		String insertPlano_Analitico = "insert into plano_analitico (semana, conteudo, objectivos, actividades, bibliografia, disciplina_codigo) values (?, ?, ?, ?, ?, ?)";
		try {
			Connection con = Conectar();
			PreparedStatement pst = con.prepareStatement(insertPlano_Analitico);
			pst.setString(1, plano_analitico.getSemana());
			pst.setString(2, plano_analitico.getConteudo());
			pst.setString(3, plano_analitico.getObjectivos());
			pst.setString(4, plano_analitico.getActividades());
			pst.setString(5, plano_analitico.getBibliografia());
			pst.setString(6, plano_analitico.getDisciplina().getCodigo_disciplina());
			pst.executeUpdate();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/** CRUD READ **/

	public ArrayList<Usuario> listUsuario() {

		ArrayList<Usuario> usuario = new ArrayList<>();

		String readUsuario = "select * from usuario order by nome";
		try {
			Connection con = Conectar();
			PreparedStatement pst = con.prepareStatement(readUsuario);
			ResultSet rs = pst.executeQuery(readUsuario);

			while (rs.next()) {
				String codigo_usuario = rs.getString(1);
				String nome = rs.getString(2);
				String email = rs.getString(3);
				String genero = rs.getString(4);
				String senha = rs.getString(5);
				String tipo = rs.getString(6);
				String telefone = rs.getString(7);
				String cidade = rs.getString(8);
				String endereco = rs.getString(9);

				usuario.add(new Usuario(codigo_usuario, nome, email, genero, senha, tipo, telefone, cidade, endereco));
			}

			con.close();
			return usuario;

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public ArrayList<Disciplina> listDisciplina() {
		ArrayList<Disciplina> disciplina = new ArrayList<>();
		String readDisciplina = "select disciplina.codigo_disciplina, disciplina.nome, disciplina.tipo_disciplina, disciplina.semestre, disciplina.creditos, disciplina.ano_frequencia, disciplina.objectivos_disciplina, curso.nome from disciplina inner join curso on disciplina.curso_codigo = curso.codigo_curso order by disciplina.nome;";
		try {
			Connection con = Conectar();
			PreparedStatement pst = con.prepareStatement(readDisciplina);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				String codigo_disciplina = rs.getString(1);
				String nome = rs.getString(2);
				String tipo_disciplina = rs.getString(3);
				String semestre = rs.getString(4);
				String creditos = rs.getString(5);
				String ano_frequencia = rs.getString(6);
				String objectivos_disciplina = rs.getString(7);
				
				Curso curso = new Curso();
				curso.setNome(rs.getString(8));

				disciplina.add(new Disciplina(codigo_disciplina, nome, tipo_disciplina, semestre, creditos,
						ano_frequencia, objectivos_disciplina, curso, null));
			}
			con.close();
			return disciplina;

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public ArrayList<Disciplina> listDisciplina1(Disciplina disciplina1, Usuario usuario) {
		ArrayList<Disciplina> disciplina = new ArrayList<>();
		String readDisciplina = "select disciplina.codigo_disciplina, disciplina.nome, disciplina.tipo_disciplina, disciplina.semestre, disciplina.creditos, disciplina.ano_frequencia, disciplina.objectivos_disciplina, curso.nome from disciplina inner join curso on disciplina.curso_codigo = curso.codigo_curso inner join usuario on disciplina.usuario_codigo = usuario.codigo_usuario  where usuario.email = ? and usuario.senha = ? order by disciplina.nome";
		try {
			Connection con = Conectar();
			PreparedStatement pst = con.prepareStatement(readDisciplina);
			pst.setString(1, usuario.getEmail());
			pst.setString(2, usuario.getSenha());
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				String codigo_disciplina = rs.getString(1);
				String nome = rs.getString(2);
				String tipo_disciplina = rs.getString(3);
				String semestre = rs.getString(4);
				String creditos = rs.getString(5);
				String ano_frequencia = rs.getString(6);
				String objectivos_disciplina = rs.getString(7);
				
				Curso curso = new Curso();
				curso.setNome(rs.getString(8));

				disciplina.add(new Disciplina(codigo_disciplina, nome, tipo_disciplina, semestre, creditos,
						ano_frequencia, objectivos_disciplina, curso, usuario));
			}
			con.close();
			return disciplina;

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public ArrayList<Plano_Analitico> listPlano_Analitico(Plano_Analitico plano_analitico1) {
		ArrayList<Plano_Analitico> plano_analitico = new ArrayList<>();
		String readPlano_Analitico = "select plano_analitico.codigo_plano_analitico, plano_analitico.semana, plano_analitico.conteudo, plano_analitico.objectivos, plano_analitico.actividades, plano_analitico.bibliografia, disciplina.codigo_disciplina from plano_analitico inner join disciplina on plano_analitico.disciplina_codigo = disciplina.codigo_disciplina where disciplina.codigo_disciplina = ?";
		try {
			Connection con = Conectar();
			PreparedStatement pst = con.prepareStatement(readPlano_Analitico);
			pst.setString(1, plano_analitico1.getDisciplina().getCodigo_disciplina());
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				String codigo_plano_analitico = rs.getString(1);
				String semana = rs.getString(2);
				String conteudo = rs.getString(3);
				String objectivos = rs.getString(4);
				String actividades = rs.getString(5);
				String bibliografia = rs.getString(6);
				
				Disciplina disciplina = new Disciplina();

				disciplina.setCodigo_disciplina(rs.getString(7));
				plano_analitico1.setDisciplina(disciplina);
				
				plano_analitico.add(new Plano_Analitico(codigo_plano_analitico, semana, conteudo, objectivos,
						actividades, bibliografia, disciplina));
			}
			con.close();
			return plano_analitico;

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public ArrayList<Faculdade> listFaculdade() {

		ArrayList<Faculdade> faculdade = new ArrayList<>();

		String readFaculdade = "select * from faculdade order by nome";
		try {
			Connection con = Conectar();
			PreparedStatement pst = con.prepareStatement(readFaculdade);
			ResultSet rs = pst.executeQuery(readFaculdade);

			while (rs.next()) {
				String codigo_faculdade = rs.getString(1);
				String nome = rs.getString(2);
				String email = rs.getString(3);
				String endereco = rs.getString(4);
				String cidade = rs.getString(5);
				String telefone = rs.getString(6);
				String fax = rs.getString(7);

				faculdade.add(new Faculdade(codigo_faculdade, nome, email, endereco, cidade, telefone, fax));
			}

			con.close();
			return faculdade;

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public ArrayList<Curso> listCurso() {
		ArrayList<Curso> curso = new ArrayList<>();
		String readCurso = "select * from curso order by nome";
		try {
			Connection con = Conectar();
			PreparedStatement pst = con.prepareStatement(readCurso);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				String codigo_curso = rs.getString(1);
				String nome = rs.getString(2);
				String grau_academico = rs.getString(3);
				String duracao = rs.getString(4);

				Curso curso1 = new Curso();
				Faculdade faculdade = new Faculdade();
				faculdade.setCodigo_faculdade(rs.getString(5));

				curso1.setFaculdade(faculdade);

				curso.add(new Curso(codigo_curso, nome, grau_academico, duracao, faculdade));
			}
			con.close();
			return curso;

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public ArrayList<Curso> consultarCursosDisciplinas() {
		ArrayList<Curso> curso = new ArrayList<>();

		String readCurso = "select * from curso left join disciplina on curso.codigo_curso = disciplina.curso_codigo where disciplina.nome is null";

		try {
			Connection con = Conectar();
			PreparedStatement pst = con.prepareStatement(readCurso);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				String codigo_curso = rs.getString(1);
				String nome = rs.getString(2);
				String grau_academico = rs.getString(3);
				String duracao = rs.getString(4);

				Curso curso1 = new Curso();
				Faculdade faculdade = new Faculdade();
				faculdade.setCodigo_faculdade(rs.getString(5));

				curso1.setFaculdade(faculdade);

				curso.add(new Curso(codigo_curso, nome, grau_academico, duracao, faculdade));
			}

			con.close();
			return curso;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/** CRUD DELETE **/

	public void deletarUtilizador(Usuario usuario) {

		String deleteUsuario = "delete from usuario where codigo_usuario =?";

		try {
			Connection con = Conectar();
			PreparedStatement pst = con.prepareStatement(deleteUsuario);
			pst.setString(1, usuario.getCodigo_usuario());
			pst.executeUpdate();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void deletarUtilizador1(Usuario usuario) {

		String deleteUsuario = "delete from plano_analitico where disciplina_codigo in (select codigo_disciplina from disciplina where usuario_codigo = ?)";

		try {
			Connection con = Conectar();
			PreparedStatement pst = con.prepareStatement(deleteUsuario);
			pst.setString(1, usuario.getCodigo_usuario());
			pst.executeUpdate();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void deletarUtilizador2(Usuario usuario) {

		String deleteUsuario = "delete from disciplina where usuario_codigo = ?";

		try {
			Connection con = Conectar();
			PreparedStatement pst = con.prepareStatement(deleteUsuario);
			pst.setString(1, usuario.getCodigo_usuario());
			pst.executeUpdate();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void deletarDisciplina(Disciplina disciplina) {

		String deleteDisciplina = "delete plano_analitico, disciplina from plano_analitico inner join disciplina on plano_analitico.disciplina_codigo = disciplina.codigo_disciplina where disciplina.codigo_disciplina = ?";

		try {
			Connection con = Conectar();
			PreparedStatement pst = con.prepareStatement(deleteDisciplina);
			pst.setString(1, disciplina.getCodigo_disciplina());
			pst.executeUpdate();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void deletarDisciplina2(Disciplina disciplina) {

		String deleteDisciplina = "delete from disciplina where codigo_disciplina = ?";

		try {
			Connection con = Conectar();
			PreparedStatement pst = con.prepareStatement(deleteDisciplina);
			pst.setString(1, disciplina.getCodigo_disciplina());
			pst.executeUpdate();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void deletarPlano_Analitico(Plano_Analitico plano_analitico) {

		String deleteplano_analitico = "delete from plano_analitico where codigo_plano_analitico = ?";

		try {
			Connection con = Conectar();
			PreparedStatement pst = con.prepareStatement(deleteplano_analitico);
			pst.setString(1, plano_analitico.getCodigo_plano_analitico());
			pst.executeUpdate();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void deletarFaculdade1(Faculdade faculdade) {

		String deleteFaculdade = "DELETE FROM plano_analitico WHERE disciplina_codigo IN (SELECT codigo_disciplina FROM disciplina WHERE curso_codigo IN (SELECT codigo_curso FROM curso WHERE faculdade_codigo = ?))";

		try {
			Connection con = Conectar();
			PreparedStatement pst = con.prepareStatement(deleteFaculdade);
			pst.setString(1, faculdade.getCodigo_faculdade());
			pst.executeUpdate();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void deletarFaculdade2(Faculdade faculdade) {

		String deleteFaculdade = "DELETE FROM disciplina WHERE curso_codigo IN (SELECT codigo_curso FROM curso WHERE faculdade_codigo = ?)";

		try {
			Connection con = Conectar();
			PreparedStatement pst = con.prepareStatement(deleteFaculdade);
			pst.setString(1, faculdade.getCodigo_faculdade());
			pst.executeUpdate();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void deletarFaculdade3(Faculdade faculdade) {

		String deleteFaculdade = "DELETE FROM curso WHERE faculdade_codigo = ?";

		try {
			Connection con = Conectar();
			PreparedStatement pst = con.prepareStatement(deleteFaculdade);
			pst.setString(1, faculdade.getCodigo_faculdade());
			pst.executeUpdate();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void deletarFaculdade(Faculdade faculdade) {

		String deleteFaculdade = "DELETE FROM faculdade WHERE codigo_faculdade = ?";

		try {
			Connection con = Conectar();
			PreparedStatement pst = con.prepareStatement(deleteFaculdade);
			pst.setString(1, faculdade.getCodigo_faculdade());
			pst.executeUpdate();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void deletarCurso(Curso curso) {

		String deleteCurso = "delete from curso where codigo_curso = ?";

		try {
			Connection con = Conectar();
			PreparedStatement pst = con.prepareStatement(deleteCurso);
			pst.setString(1, curso.getCodigo_curso());
			pst.executeUpdate();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void deletarCurso1(Curso curso) {

		String deleteCurso = "delete from plano_analitico where disciplina_codigo in (select codigo_disciplina from disciplina where curso_codigo = ?)";

		try {
			Connection con = Conectar();
			PreparedStatement pst = con.prepareStatement(deleteCurso);
			pst.setString(1, curso.getCodigo_curso());
			pst.executeUpdate();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void deletarCurso2(Curso curso) {

		String deleteCurso = "delete from disciplina where curso_codigo = ?";

		try {
			Connection con = Conectar();
			PreparedStatement pst = con.prepareStatement(deleteCurso);
			pst.setString(1, curso.getCodigo_curso());
			pst.executeUpdate();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/** CRUD UPDATE **/

	public void selecionarDisciplina(Disciplina disciplina) {
		String updateDisciplina = "select * from disciplina where codigo_disciplina = ?";
		try {
			Connection con = Conectar();
			PreparedStatement pst = con.prepareStatement(updateDisciplina);
			pst.setString(1, disciplina.getCodigo_disciplina());
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				disciplina.setCodigo_disciplina(rs.getString(1));
				disciplina.setNome(rs.getString(2));
				disciplina.setTipo_disciplina(rs.getString(3));
				disciplina.setSemestre(rs.getString(4));
				disciplina.setCreditos(rs.getString(5));
				disciplina.setAno_frequencia(rs.getString(6));
				disciplina.setObjectivos_disciplina(rs.getString(7));

				Curso curso = new Curso();

				curso.setCodigo_curso(rs.getString(8));
				disciplina.setCurso(curso);
			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void selecionarPlano_Analitico(Plano_Analitico plano_analitico) {
		String updatePlano_Analitico = "select * from plano_analitico where codigo_plano_analitico = ?";
		try {
			Connection con = Conectar();
			PreparedStatement pst = con.prepareStatement(updatePlano_Analitico);
			pst.setString(1, plano_analitico.getCodigo_plano_analitico());
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				plano_analitico.setCodigo_plano_analitico(rs.getString(1));
				plano_analitico.setSemana(rs.getString(2));
				plano_analitico.setConteudo(rs.getString(3));
				plano_analitico.setObjectivos(rs.getString(4));
				plano_analitico.setActividades(rs.getString(5));
				plano_analitico.setBibliografia(rs.getString(6));

				Disciplina disciplina = new Disciplina();

				disciplina.setCodigo_disciplina(rs.getString(7));
				plano_analitico.setDisciplina(disciplina);

			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void selecionarUsuario(Usuario usuario) {
		String updateUsuario = "select * from usuario where email = ? or codigo_usuario = ?";
		try {
			Connection con = Conectar();
			PreparedStatement pst = con.prepareStatement(updateUsuario);
			pst.setString(1, usuario.getEmail());
			pst.setString(2, usuario.getCodigo_usuario());
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				usuario.setCodigo_usuario(rs.getString(1));
				usuario.setNome(rs.getString(2));
				usuario.setEmail(rs.getString(3));
				usuario.setGenero(rs.getString(4));
				usuario.setSenha(rs.getString(5));
				usuario.setTipo(rs.getString(6));
				usuario.setTelefone(rs.getString(7));
				usuario.setCidade(rs.getString(8));
				usuario.setEndereco(rs.getString(9));
			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void selecionarUsuario1(Usuario usuario) {
		String updateUsuario = "select * from usuario where codigo_usuario = ?";
		try {
			Connection con = Conectar();
			PreparedStatement pst = con.prepareStatement(updateUsuario);
			pst.setString(1, usuario.getCodigo_usuario());
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				usuario.setCodigo_usuario(rs.getString(1));
				usuario.setNome(rs.getString(2));
				usuario.setEmail(rs.getString(3));
				usuario.setGenero(rs.getString(4));
				usuario.setSenha(rs.getString(5));
				usuario.setTipo(rs.getString(6));
				usuario.setTelefone(rs.getString(7));
				usuario.setCidade(rs.getString(8));
				usuario.setEndereco(rs.getString(9));
			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void getDisc_codigo(Disciplina disciplina) {
		String getCodigo = "select disciplina.codigo_disciplina from disciplina where disciplina.codigo_disciplina =?";
		try {
			Connection con = Conectar();
			PreparedStatement pst = con.prepareStatement(getCodigo);
			pst.setString(1, disciplina.getCodigo_disciplina());
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				disciplina.setCodigo_disciplina(rs.getString(1));
			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void selecionarFaculdade(Faculdade faculdade) {
		String updateFaculdade = "select * from faculdade where codigo_faculdade = ?";
		try {
			Connection con = Conectar();
			PreparedStatement pst = con.prepareStatement(updateFaculdade);
			pst.setString(1, faculdade.getCodigo_faculdade());
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				faculdade.setCodigo_faculdade(rs.getString(1));
				faculdade.setNome(rs.getString(2));
				faculdade.setEmail(rs.getString(3));
				faculdade.setEndereco(rs.getString(4));
				faculdade.setCidade(rs.getString(5));
				faculdade.setTelefone(rs.getString(6));
				faculdade.setFax(rs.getString(7));
			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void selecionarCurso(Curso curso) {
		String updateCurso = "select * from curso where codigo_curso = ?";
		try {
			Connection con = Conectar();
			PreparedStatement pst = con.prepareStatement(updateCurso);
			pst.setString(1, curso.getCodigo_curso());
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				curso.setCodigo_curso(rs.getString(1));
				curso.setNome(rs.getString(2));
				curso.setGrau_academico(rs.getString(3));
				curso.setDuracao(rs.getString(4));

				Faculdade faculdade = new Faculdade();

				faculdade.setCodigo_faculdade(rs.getString(5));
				curso.setFaculdade(faculdade);
			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void alterarUsuario(Usuario usuario) {
		String alterUser00 = "update usuario set nome=?, email=?, genero=?, senha=?, tipo=?, telefone=?, cidade=?, endereco=? where codigo_usuario = ?";
		try {
			Connection con = Conectar();
			PreparedStatement pst = con.prepareStatement(alterUser00);

			pst.setString(1, usuario.getNome());
			pst.setString(2, usuario.getEmail());
			pst.setString(3, usuario.getGenero());
			pst.setString(4, usuario.getSenha());
			pst.setString(5, usuario.getTipo());
			pst.setString(6, usuario.getTelefone());
			pst.setString(7, usuario.getCidade());
			pst.setString(8, usuario.getEndereco());
			pst.setString(9, usuario.getCodigo_usuario());
			pst.executeUpdate();

			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void alterarPLanoAnaltico(Plano_Analitico plano_analitico) {
		String alterUser00 = "update plano_analitico set semana=?, conteudo=?, objectivos=?, actividades=?, bibliografia=? where codigo_plano_analitico = ?";
		try {
			Connection con = Conectar();
			PreparedStatement pst = con.prepareStatement(alterUser00);
			
			pst.setString(1, plano_analitico.getSemana());
			pst.setString(2, plano_analitico.getConteudo());
			pst.setString(3, plano_analitico.getObjectivos());
			pst.setString(4, plano_analitico.getActividades());
			pst.setString(5, plano_analitico.getBibliografia());
			pst.setString(6, plano_analitico.getCodigo_plano_analitico());
			pst.executeUpdate();

			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void alterarFaculdade(Faculdade faculdade) {
		String alterFaculdade = "update faculdade set nome=?, email=?, endereco=?, cidade=?, telefone=?, fax=? where codigo_faculdade = ?";
		try {
			Connection con = Conectar();
			PreparedStatement pst = con.prepareStatement(alterFaculdade);

			pst.setString(1, faculdade.getNome());
			pst.setString(2, faculdade.getEmail());
			pst.setString(3, faculdade.getEndereco());
			pst.setString(4, faculdade.getCidade());
			pst.setString(5, faculdade.getTelefone());
			pst.setString(6, faculdade.getFax());
			pst.setString(7, faculdade.getCodigo_faculdade());
			pst.executeUpdate();

			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void alterarCurso(Curso curso) {
		String alterCurso00 = "update curso set nome =?, grau_academico =?, duracao =? where codigo_curso =?";
		try {
			Connection con = Conectar();
			PreparedStatement pst = con.prepareStatement(alterCurso00);

			pst.setString(1, curso.getNome());
			pst.setString(2, curso.getGrau_academico());
			pst.setString(3, curso.getDuracao());
			pst.setString(4, curso.getCodigo_curso());
			pst.executeUpdate();

			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void alterarDisciplina(Disciplina disciplina) {
		String alterDisciplina00 = "update disciplina set nome =?, tipo_disciplina =?, semestre =?, creditos =?, ano_frequencia =?, objectivos_disciplina =? where codigo_disciplina =?";
		try {
			Connection con = Conectar();
			PreparedStatement pst = con.prepareStatement(alterDisciplina00);
			pst.setString(1, disciplina.getNome());
			pst.setString(2, disciplina.getTipo_disciplina());
			pst.setString(3, disciplina.getSemestre());
			pst.setString(4, disciplina.getCreditos());
			pst.setString(5, disciplina.getAno_frequencia());
			pst.setString(6, disciplina.getObjectivos_disciplina());
			pst.setString(7, disciplina.getCodigo_disciplina());
			pst.executeUpdate();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void alterarSenha(Usuario usuario) {
		String alterSenh = "update usuario set senha =? where codigo_usuario =?";
		try {
			Connection con = Conectar();
			PreparedStatement pst = con.prepareStatement(alterSenh);
			pst.setString(1, usuario.getSenha());
			pst.setString(2, usuario.getCodigo_usuario());
			pst.executeUpdate();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Autenticacao de usuarios

	public String validarLogin(Usuario usuario) {

		

		String email = usuario.getEmail();
		String senha = usuario.getSenha();
		
		String sqlLoginUsuario = "select * from usuario";
		
		try {

			Connection con = Conectar();
			PreparedStatement pst = con.prepareStatement(sqlLoginUsuario);
			ResultSet rs = pst.executeQuery();

			while (rs.next()) {
				usuario.setCodigo_usuario(rs.getString(1));
				usuario.setNome(rs.getString(2));
				usuario.setEmail(rs.getString(3));
				usuario.setGenero(rs.getString(4));
				usuario.setSenha(rs.getString(5));
				usuario.setTipo(rs.getString(6)); 
				usuario.setTelefone(rs.getString(7));
				usuario.setCidade(rs.getString(8));
				usuario.setEndereco(rs.getString(9));

				if (email.equals(usuario.getEmail()) && senha.equals(usuario.getSenha()) && usuario.getTipo().equals("Admin")) {
					return "Administrador";
				} else if (email.equals(usuario.getEmail()) && senha.equals(usuario.getSenha()) && usuario.getTipo().equals("Docente")) {
					return "Teacher";
				}
			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "Erro, email ou senha inválida!";
	}
	
	
	public void gerarPlano(Faculdade faculdade, Curso curso1, Disciplina disciplina1, Usuario usuario1) {

		String readPlano = "select faculdade.nome, curso.nome, disciplina.nome, disciplina.codigo_disciplina, disciplina.tipo_disciplina, curso.grau_academico, disciplina.ano_frequencia, disciplina.semestre, disciplina.creditos, usuario.nome, usuario.telefone, usuario.email, objectivos_disciplina  FROM disciplina INNER JOIN curso ON disciplina.curso_codigo = curso.codigo_curso inner join faculdade on curso.faculdade_codigo = faculdade.codigo_faculdade INNER JOIN usuario ON disciplina.usuario_codigo = usuario.codigo_usuario WHERE disciplina.codigo_disciplina = ?";

		try {
			Connection con = Conectar();
			PreparedStatement pst = con.prepareStatement(readPlano);
			pst.setString(1, disciplina1.getCodigo_disciplina());
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				faculdade.setNome(rs.getString(1));
				curso1.setNome(rs.getString(2));
				disciplina1.setNome(rs.getString(3));
				disciplina1.setCodigo_disciplina(rs.getString(4));
				disciplina1.setTipo_disciplina(rs.getString(5));
				curso1.setGrau_academico(rs.getString(6));
				disciplina1.setAno_frequencia(rs.getString(7));
				disciplina1.setSemestre(rs.getString(8));
				disciplina1.setCreditos(rs.getString(9));
				usuario1.setNome(rs.getString(10));
				usuario1.setTelefone(rs.getString(11));
				usuario1.setEmail(rs.getString(12));
				disciplina1.setObjectivos_disciplina(rs.getString(13));
			}

			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
