package controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import model.Usuario;
import model.Plano_Analitico;
import model.Disciplina;
import model.Curso;
import model.Faculdade;
import model.DAO;

@WebServlet(name = "/Controller", urlPatterns = { "/Controller", "/encerrar", "/main", "/admin-gerir-create-user",
		"/painel", "/admin-gerir-user", "/admin-gerir-plan", "/select-faculdade", "/admin-create-user",
		"/admin-redefinir-senha", "/home", "/user-gerir-plan", "/user-redefinir-senha", "/select-faculdade01",
		"/updateUtilizador", "/inserirUser", "/deleteUser1", "/insert-plann", "/deleteCadeira1", "/selectUser1",
		"/admin-insert-plann", "/verPlano", "/deleteCadeira2", "/viwplann", "/selectDisc2", "/selectionplan",
		"/UpdateDisc1", "/UpdateDisc2", "/UpadateSenha", "/searchPlano", "/UpadateSenha1", "/user-redefinir-senha1",
		"/inserirFaculdade", "/inserirCurso", "/deleteFaculdade1", "/updateFaculdade", "/gerir-curso",
		"/selectFaculdade1", "/insertDisc01", "/inserirDisc01", "/inserirDisc02", "/insertDisc02", "/faculdade",
		"/curso", "/select-curso00", "/select-curso01", "/deleteCurso1", "/updateCurso", "/selectCurso1", "/plano",
		"/insert-faculdade", "/gerir-faculdade", "/plan", "/report", "/reportCurso", "/relatoriocurso",
		"/reportFaculdade", "/reportUser", "/verPlan", "/selectPlan1", "/selectPlan10", "/alterarPlan007",
		"/alterarPlan008", "/apagarPlano", "/apagarPlano1", "/downloadManual", "/getEmail" })

public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;

	DAO dao = new DAO();
	Usuario usuario = new Usuario();
	Plano_Analitico plano_analitico = new Plano_Analitico();
	Disciplina disciplina = new Disciplina();
	Curso curso = new Curso();
	Faculdade faculdade = new Faculdade();

	private HttpSession session;

	public Controller() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String lut = request.getServletPath();
		if (lut.equals("/main")) {
			Login(request, response);

		} else if (lut.equals("/admin-gerir-plan")) {
			adminGerirPlan(request, response);

		} else if (lut.equals("/select-faculdade")) {
			seleccionarFaculdade00(request, response);

		} else if (lut.equals("/admin-gerir-user")) {
			adminGerirUser(request, response);

		} else if (lut.equals("/admin-gerir-create-user")) {
			adminGerirCreateUser(request, response);
		} else if (lut.equals("/admin-create-user")) {
			adminCreateUser(request, response);
		} else if (lut.equals("/admin-redefinir-senha")) {
			adminRedefinirSenha(request, response);
		} else if (lut.equals("/home")) {
			userPaginaInicial(request, response);
		} else if (lut.equals("/user-gerir-plan")) {
			userGerirPlan(request, response);
		} else if (lut.equals("/user-redefinir-senha")) {
			userRedefinirSenha(request, response);
		} else if (lut.equals("/select-faculdade01")) {
			seleccionarFaculdade01(request, response);
		} else if (lut.equals("/inserirUser")) {
			CreateUser1(request, response);
		} else if (lut.equals("/deleteUser1")) {
			removerUser(request, response);
		} else if (lut.equals("/selectUser1")) {
			seleccionarUser(request, response);
		} else if (lut.equals("/updateUtilizador")) {
			updateUser11(request, response);
		} else if (lut.equals("/admin-insert-plann")) {
			adminGerirCreatePlan3(request, response);
		} else if (lut.equals("/verPlano")) {
			VerPlano1(request, response);
		} else if (lut.equals("/deleteCadeira1")) {
			removerPlan(request, response);
		} else if (lut.equals("/deleteCadeira2")) {
			removerPlan1(request, response);
		} else if (lut.equals("/insert-plann")) {
			CreatePlan3(request, response);
		} else if (lut.equals("/encerrar")) {
			exit(request, response);
		} else if (lut.equals("/painel")) {
			control(request, response);
		} else if (lut.equals("/gerir-curso")) {
			adminGerirCurso(request, response);
		} else if (lut.equals("/gerir-faculdade")) {
			adminGerirFaculdade(request, response);
		} else if (lut.equals("/report")) {
			gerarPlano(request, response);
		} else if (lut.equals("/selectDisc2")) {
			seleccionarDisciplina002(request, response);
		} else if (lut.equals("/UpdateDisc1")) {
			EditarDisciplina009(request, response);
		} else if (lut.equals("/selectionplan")) {
			SelectionDisciplina0003(request, response);
		} else if (lut.equals("/UpdateDisc2")) {
			EditarDisciplina(request, response);
		} else if (lut.equals("/UpadateSenha")) {
			alterarSenha(request, response);
		} else if (lut.equals("/searchPlano")) {
			SearchPl1(request, response);
		} else if (lut.equals("/UpadateSenha1")) {
			alterarSenha1(request, response);
		} else if (lut.equals("/user-redefinir-senha1")) {
			RedefinirSenha1(request, response);
		} else if (lut.equals("/insert-faculdade")) {
			inserirFaculdade(request, response);
		} else if (lut.equals("/inserirCurso")) {
			insertCurso(request, response);
		} else if (lut.equals("/inserirFaculdade")) {
			insertFaculdade(request, response);
		} else if (lut.equals("/faculdade")) {
			faculdade1(request, response);
		} else if (lut.equals("/selectFaculdade1")) {
			seleccionarFaculdade(request, response);
		} else if (lut.equals("/updateFaculdade")) {
			EditarFaculdade(request, response);
		} else if (lut.equals("/deleteFaculdade1")) {
			removerFaculdade(request, response);
		} else if (lut.equals("/curso")) {
			curso1(request, response);
		} else if (lut.equals("/selectCurso1")) {
			selectCurso11(request, response);
		} else if (lut.equals("/updateCurso")) {
			updateCurso1(request, response);
		} else if (lut.equals("/deleteCurso1")) {
			deleteCurso10(request, response);
		} else if (lut.equals("/select-curso00")) {
			selectCurso1(request, response);
		} else if (lut.equals("/select-curso01")) {
			selectCurso2(request, response);
		} else if (lut.equals("/insertDisc01")) {
			insertDisc011(request, response);
		} else if (lut.equals("/insertDisc02")) {
			insertDisc022(request, response);
		} else if (lut.equals("/inserirDisc01")) {
			insertDisc(request, response);
		} else if (lut.equals("/inserirDisc02")) {
			insertDisc1(request, response);
		} else if (lut.equals("/plano")) {
			selectCodigo(request, response);
		} else if (lut.equals("/plan")) {
			selectCodigo1(request, response);
		} else if (lut.equals("/reportCurso")) {
			gerarCurso(request, response);
		} else if (lut.equals("/reportFaculdade")) {
			gerarFaculdade(request, response);
		} else if (lut.equals("/reportUser")) {
			reportuser1(request, response);
		} else if (lut.equals("/relatoriocurso")) {
			CursoDisciplina(request, response);
		} else if (lut.equals("/verPlan")) {
			VerPlano100(request, response);
		} else if (lut.equals("/selectPlan1")) {
			seleccionarPlano(request, response);
		} else if (lut.equals("/selectPlan10")) {
			seleccionarPlano9(request, response);
		} else if (lut.equals("/alterarPlan007")) {
			AlterarPlan(request, response);
		} else if (lut.equals("/alterarPlan008")) {
			AlterarPlan1(request, response);
		} else if (lut.equals("/apagarPlano")) {
			ExcluirPlano(request, response);
		} else if (lut.equals("/apagarPlano1")) {
			ExcluirPlano1(request, response);
		} else if (lut.equals("/downloadManual")) {
			downloadManualPDF(request, response);
		} else if (lut.equals("/getEmail")) {
			getLink(request, response);
		}
	}

	// Link para redefinicao de senha

	protected void getLink(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String email = "lutjalilo78@gmail.com";
		String senha = "ggodhkgnctlbwctw";
		String email1 = request.getParameter("email");

		Properties props = new Properties();
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "587");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");

		Session session = Session.getInstance(props, new Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(email, senha);
			}
		});

		try {
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(email));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(email1));
			message.setSubject("Redefinição de Nova Senha");
			message.setText(
					"Olá! Aqui está o link para redefinição de nova senha: http://localhost:8080/analyticalplan/redefinir-senha.jsp");
			Transport.send(message);
		} catch (Exception e) {
			e.printStackTrace();
		}

		response.sendRedirect("sucess.jsp");
	}

	// Download Manual
	protected void downloadManualPDF(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String file = "C:/Users/Lut Jalilo/eclipse-workspace/analyticalplan/Manual.pdf";
		File download = new File(file);
		FileInputStream inStream = new FileInputStream(download);

		String relativePath = getServletContext().getRealPath("");

		ServletContext context = getServletContext();

		String mimeType = context.getMimeType(file);

		if (mimeType == null) {
			mimeType = "apllication/octet-stream";
		}

		response.setContentType(mimeType);
		response.setContentLength((int) download.length());

		String headerKey = "Content-Disposition";
		String headerValue = String.format("attachment; filename=\"%s\"", download.getName());
		response.setHeader(headerKey, headerValue);

		OutputStream outStream = response.getOutputStream();

		byte[] buffer = new byte[4096];
		int byteReads = -1;

		while ((byteReads = inStream.read(buffer)) != -1) {
			outStream.write(buffer, 0, byteReads);
		}
		inStream.close();
		outStream.close();
	}

	// Gerar Relatorio de Cursos sem Planos em PDF
	protected void CursoDisciplina(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		Document documento = new Document();

		try {
			response.setContentType("apllication/pdf");
			// Nome do documento
			response.addHeader("Content-Disposition", "inline; filename=" + "Relatório de Cursos sem Planos.pdf");

			// Criar novo plano

			PdfWriter.getInstance(documento, response.getOutputStream());

			// Abrir o documento

			documento.open();

			Paragraph par1 = new Paragraph();
			Font titulo1 = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD, BaseColor.BLACK);

			Image image = Image
					.getInstance("C:\\Users\\Lut Jalilo\\eclipse-workspace\\analyticalplan\\src\\main\\webapp\\img\\ucm5.png");
			image.scaleAbsolute(500, 90);
			documento.add(image);
			par1.add(new Paragraph("Universidade Católica de Moçambique", titulo1));
			par1.add(new Paragraph("Relatório de Cursos sem Planos Analíticos", titulo1));
			par1.setAlignment(Element.ALIGN_CENTER);
			par1.add(new Phrase(Chunk.NEWLINE));

			documento.add(par1);

			Paragraph par2 = new Paragraph();
			Font titulo = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD, BaseColor.BLACK);
			PdfPTable tabela2 = new PdfPTable(4);

			// Cabecalho
			PdfPCell col25 = new PdfPCell(new Paragraph("Código ", titulo));
			PdfPCell col26 = new PdfPCell(new Paragraph("Nome do Curso", titulo));
			PdfPCell col27 = new PdfPCell(new Paragraph("Grau Acadêmico", titulo));
			PdfPCell col28 = new PdfPCell(new Paragraph("Duração", titulo));

			tabela2.setWidthPercentage(95);
			tabela2.setWidthPercentage(95);
			tabela2.setWidthPercentage(95);
			tabela2.setWidthPercentage(95);

			tabela2.addCell(col25);
			tabela2.addCell(col26);
			tabela2.addCell(col27);
			tabela2.addCell(col28);

			ArrayList<Curso> listCurso = dao.consultarCursosDisciplinas();
			for (int i = 0; i < listCurso.size(); i++) {
				tabela2.addCell(listCurso.get(i).getCodigo_curso());
				tabela2.addCell(listCurso.get(i).getNome());
				tabela2.addCell(listCurso.get(i).getGrau_academico());
				tabela2.addCell(listCurso.get(i).getDuracao());
			}

			documento.add(tabela2);

			documento.add(new Paragraph(" "));
			documento.add(new Paragraph(" "));

			SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			String formattedDate = df.format(new Date());

			Paragraph par3 = new Paragraph();
			par3.add(new Paragraph("Data: " + formattedDate));
			par3.setAlignment(Element.ALIGN_CENTER);
			documento.add(par3);

			documento.close();

		} catch (Exception e) {
			e.printStackTrace();
			documento.close();
		}

	}

	// Gerar Relatorio de Faculdades em PDF
	protected void reportuser1(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		Document documento = new Document();

		try {

			response.setContentType("apllication/pdf");
			// Nome do documento
			response.addHeader("Content-Disposition", "inline; filename=" + "Usuários.pdf");

			// Criar novo plano

			PdfWriter.getInstance(documento, response.getOutputStream());

			// Abrir o documento

			documento.open();

			Paragraph par1 = new Paragraph();
			Font titulo1 = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD, BaseColor.BLACK);

			Image image = Image
					.getInstance("C:\\Users\\Lut Jalilo\\eclipse-workspace\\analyticalplan\\src\\main\\webapp\\img\\ucm5.png");
			image.scaleAbsolute(500, 90);
			documento.add(image);
			par1.add(new Paragraph("Universidade Católica de Moçambique", titulo1));
			par1.add(new Paragraph("Usuários", titulo1));
			par1.setAlignment(Element.ALIGN_CENTER);
			par1.add(new Phrase(Chunk.NEWLINE));

			documento.add(par1);

			Paragraph par2 = new Paragraph();
			Font titulo = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD, BaseColor.BLACK);
			PdfPTable tabela2 = new PdfPTable(6);

			// Cabecalho
			PdfPCell col25 = new PdfPCell(new Paragraph("Código ", titulo));
			PdfPCell col26 = new PdfPCell(new Paragraph("Nome", titulo));
			PdfPCell col27 = new PdfPCell(new Paragraph("E-mail", titulo));
			PdfPCell col28 = new PdfPCell(new Paragraph("Género", titulo));
			PdfPCell col29 = new PdfPCell(new Paragraph("Senha", titulo));
			PdfPCell col30 = new PdfPCell(new Paragraph("Tipo", titulo));

			tabela2.setWidthPercentage(100);
			tabela2.setWidthPercentage(100);
			tabela2.setWidthPercentage(100);
			tabela2.setWidthPercentage(100);
			tabela2.setWidthPercentage(100);
			tabela2.setWidthPercentage(100);

			tabela2.addCell(col25);
			tabela2.addCell(col26);
			tabela2.addCell(col27);
			tabela2.addCell(col28);
			tabela2.addCell(col29);
			tabela2.addCell(col30);

			ArrayList<Usuario> listUsuario = dao.listUsuario();
			for (int i = 0; i < listUsuario.size(); i++) {
				tabela2.addCell(listUsuario.get(i).getCodigo_usuario());
				tabela2.addCell(listUsuario.get(i).getNome());
				tabela2.addCell(listUsuario.get(i).getEmail());
				tabela2.addCell(listUsuario.get(i).getGenero());
				tabela2.addCell(listUsuario.get(i).getSenha());
				tabela2.addCell(listUsuario.get(i).getTipo());
			}

			documento.add(tabela2);

			documento.add(new Paragraph(" "));
			documento.add(new Paragraph(" "));

			SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			String formattedDate = df.format(new Date());

			Paragraph par3 = new Paragraph();
			par3.add(new Paragraph("Data: " + formattedDate));
			par3.setAlignment(Element.ALIGN_CENTER);
			documento.add(par3);

			documento.close();

		} catch (Exception e) {
			e.printStackTrace();
			documento.close();
		}

	}

	// Gerar Relatorio de Faculdades em PDF
	protected void gerarFaculdade(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		Document documento = new Document();

		try {

			response.setContentType("apllication/pdf");
			// Nome do documento
			response.addHeader("Content-Disposition", "inline; filename=" + "Relatório de Faculdades.pdf");

			// Criar novo plano

			PdfWriter.getInstance(documento, response.getOutputStream());

			// Abrir o documento

			documento.open();

			Paragraph par1 = new Paragraph();
			Font titulo1 = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD, BaseColor.BLACK);

			Image image = Image
					.getInstance("C:\\Users\\Lut Jalilo\\eclipse-workspace\\analyticalplan\\src\\main\\webapp\\img\\ucm5.png");
			image.scaleAbsolute(500, 90);
			documento.add(image);
			par1.add(new Paragraph("Universidade Católica de Moçambique", titulo1));
			par1.add(new Paragraph("Relatório de Faculdades", titulo1));
			par1.setAlignment(Element.ALIGN_CENTER);
			par1.add(new Phrase(Chunk.NEWLINE));

			documento.add(par1);

			Paragraph par2 = new Paragraph();
			Font titulo = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD, BaseColor.BLACK);
			PdfPTable tabela2 = new PdfPTable(7);

			// Cabecalho
			PdfPCell col25 = new PdfPCell(new Paragraph("Código ", titulo));
			PdfPCell col26 = new PdfPCell(new Paragraph("Nome da Faculdade", titulo));
			PdfPCell col27 = new PdfPCell(new Paragraph("E-mail", titulo));
			PdfPCell col28 = new PdfPCell(new Paragraph("Rua", titulo));
			PdfPCell col29 = new PdfPCell(new Paragraph("Cidade", titulo));
			PdfPCell col30 = new PdfPCell(new Paragraph("Telefone", titulo));
			PdfPCell col31 = new PdfPCell(new Paragraph("Fax", titulo));

			tabela2.setWidthPercentage(100);
			tabela2.setWidthPercentage(100);
			tabela2.setWidthPercentage(100);
			tabela2.setWidthPercentage(100);
			tabela2.setWidthPercentage(100);
			tabela2.setWidthPercentage(100);
			tabela2.setWidthPercentage(100);

			tabela2.addCell(col25);
			tabela2.addCell(col26);
			tabela2.addCell(col27);
			tabela2.addCell(col28);
			tabela2.addCell(col29);
			tabela2.addCell(col30);
			tabela2.addCell(col31);

			ArrayList<Faculdade> listFaculdade = dao.listFaculdade();
			for (int i = 0; i < listFaculdade.size(); i++) {
				tabela2.addCell(listFaculdade.get(i).getCodigo_faculdade());
				tabela2.addCell(listFaculdade.get(i).getNome());
				tabela2.addCell(listFaculdade.get(i).getEmail());
				tabela2.addCell(listFaculdade.get(i).getEndereco());
				tabela2.addCell(listFaculdade.get(i).getCidade());
				tabela2.addCell(listFaculdade.get(i).getTelefone());
				tabela2.addCell(listFaculdade.get(i).getFax());
			}

			documento.add(tabela2);

			documento.add(new Paragraph(" "));
			documento.add(new Paragraph(" "));

			SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			String formattedDate = df.format(new Date());

			Paragraph par3 = new Paragraph();
			par3.add(new Paragraph("Data: " + formattedDate));
			par3.setAlignment(Element.ALIGN_CENTER);
			documento.add(par3);
			documento.close();

		} catch (Exception e) {
			e.printStackTrace();
			documento.close();
		}

	}

	// Gerar Relatorio de Cursos em PDF
	protected void gerarCurso(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		Document documento = new Document();

		try {
			String codigo_disciplina = request.getParameter("codigo_disciplina");
			disciplina.setCodigo_disciplina(codigo_disciplina);
			dao.listCurso();

			response.setContentType("apllication/pdf");
			// Nome do documento
			response.addHeader("Content-Disposition", "inline; filename=" + "Relatório de Cursos.pdf");

			// Criar novo plano

			PdfWriter.getInstance(documento, response.getOutputStream());

			// Abrir o documento

			documento.open();

			Paragraph par1 = new Paragraph();
			Font titulo1 = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD, BaseColor.BLACK);

			Image image = Image
					.getInstance("C:\\Users\\Lut Jalilo\\eclipse-workspace\\analyticalplan\\src\\main\\webapp\\img\\ucm5.png");
			image.scaleAbsolute(500, 90);
			documento.add(image);
			par1.add(new Paragraph("Universidade Católica de Moçambique", titulo1));
			par1.add(new Paragraph("Relatório de Cursos", titulo1));
			par1.setAlignment(Element.ALIGN_CENTER);
			par1.add(new Phrase(Chunk.NEWLINE));

			documento.add(par1);

			Paragraph par2 = new Paragraph();
			Font titulo = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD, BaseColor.BLACK);
			PdfPTable tabela2 = new PdfPTable(4);

			// Cabecalho
			PdfPCell col25 = new PdfPCell(new Paragraph("Código ", titulo));
			PdfPCell col26 = new PdfPCell(new Paragraph("Nome do Curso", titulo));
			PdfPCell col27 = new PdfPCell(new Paragraph("Grau Acadêmico", titulo));
			PdfPCell col28 = new PdfPCell(new Paragraph("Duração", titulo));

			tabela2.setWidthPercentage(95);
			tabela2.setWidthPercentage(95);
			tabela2.setWidthPercentage(95);
			tabela2.setWidthPercentage(95);

			tabela2.addCell(col25);
			tabela2.addCell(col26);
			tabela2.addCell(col27);
			tabela2.addCell(col28);

			ArrayList<Curso> listCurso = dao.listCurso();
			for (int i = 0; i < listCurso.size(); i++) {
				tabela2.addCell(listCurso.get(i).getCodigo_curso());
				tabela2.addCell(listCurso.get(i).getNome());
				tabela2.addCell(listCurso.get(i).getGrau_academico());
				tabela2.addCell(listCurso.get(i).getDuracao());
			}

			documento.add(tabela2);

			documento.add(new Paragraph(" "));
			documento.add(new Paragraph(" "));

			SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			String formattedDate = df.format(new Date());

			Paragraph par3 = new Paragraph();
			par3.add(new Paragraph("Data: " + formattedDate));
			par3.setAlignment(Element.ALIGN_CENTER);
			documento.add(par3);
			documento.close();

		} catch (Exception e) {
			e.printStackTrace();
			documento.close();
		}

	}

	protected void selectCodigo(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String codigo_disciplina = request.getParameter("codigo_disciplina");
		disciplina.setCodigo_disciplina(codigo_disciplina);
		dao.getDisc_codigo(disciplina);
		request.setAttribute("codigo_disciplina", disciplina.getCodigo_disciplina());
		request.setAttribute("nome", disciplina.getNome());
		RequestDispatcher rd = request.getRequestDispatcher("insert-plan.jsp");
		rd.forward(request, response);
	}

	protected void selectCodigo1(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String codigo_disciplina = request.getParameter("codigo_disciplina");
		disciplina.setCodigo_disciplina(codigo_disciplina);
		dao.getDisc_codigo(disciplina);
		request.setAttribute("codigo_disciplina", disciplina.getCodigo_disciplina());
		request.setAttribute("nome", disciplina.getNome());
		RequestDispatcher rd = request.getRequestDispatcher("insert-plan1.jsp");
		rd.forward(request, response);
	}

	protected void insertDisc(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String email = "lutjalilo78@gmail.com";
		String senha = "ggodhkgnctlbwctw";
		String curso1 = request.getParameter("curso");
		String disc = request.getParameter("nome");
		String tipo_disciplina = request.getParameter("tipo_disciplina");
		String semestre = request.getParameter("semestre");
		String creditos = request.getParameter("creditos");
		String ano_frequencia = request.getParameter("ano_frequencia");

		disciplina.setNome(request.getParameter("nome"));
		disciplina.setTipo_disciplina(request.getParameter("tipo_disciplina"));
		disciplina.setSemestre(request.getParameter("semestre"));
		disciplina.setCreditos(request.getParameter("creditos"));
		disciplina.setAno_frequencia(request.getParameter("ano_frequencia"));
		disciplina.setObjectivos_disciplina(request.getParameter("objectivos_disciplina"));
		curso.setCodigo_curso(request.getParameter("codigo_curso"));
		disciplina.setCurso(curso);
		usuario.setCodigo_usuario(request.getParameter("codigo_usuario"));
		disciplina.setUsuario(usuario);
		dao.inserirDisciplina(disciplina);

		Properties props = new Properties();
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "587");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");

		Session session = Session.getInstance(props, new Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(email, senha);
			}
		});

		try {
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(email));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse("709190656@ucm.ac.mz"));
			message.setSubject("Plano Analítico de " + disc);
			message.setText("Olá! O Plano Analítico de " + disc + " foi criado." + " Curso: " + curso1 + ", Tipo de Disciplina: " + tipo_disciplina + ", Semestre: " + semestre + ", Creditos: " + creditos + ", Ano de Frequência: " + ano_frequencia + ".");
			Transport.send(message);

		} catch (Exception e) {
			e.printStackTrace();
		}
		response.sendRedirect("admin-gerir-plan");
	}

	protected void insertDisc1(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String email = "lutjalilo78@gmail.com";
		String senha = "ggodhkgnctlbwctw";
		String curso1 = request.getParameter("curso");
		String disc = request.getParameter("nome");
		String tipo_disciplina = request.getParameter("tipo_disciplina");
		String semestre = request.getParameter("semestre");
		String creditos = request.getParameter("creditos");
		String ano_frequencia = request.getParameter("ano_frequencia");

		disciplina.setNome(request.getParameter("nome"));
		disciplina.setTipo_disciplina(request.getParameter("tipo_disciplina"));
		disciplina.setSemestre(request.getParameter("semestre"));
		disciplina.setCreditos(request.getParameter("creditos"));
		disciplina.setAno_frequencia(request.getParameter("ano_frequencia"));
		disciplina.setObjectivos_disciplina(request.getParameter("objectivos_disciplina"));
		curso.setCodigo_curso(request.getParameter("codigo_curso"));
		disciplina.setCurso(curso);
		usuario.setCodigo_usuario(request.getParameter("codigo_usuario"));
		disciplina.setUsuario(usuario);
		dao.inserirDisciplina(disciplina);

		Properties props = new Properties();
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "587");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");

		Session session = Session.getInstance(props, new Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(email, senha);
			}
		});

		try {
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(email));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse("709190656@ucm.ac.mz"));
			message.setSubject("Plano Analítico de " + disc);
			message.setText("Olá! O Plano Analítico de " + disc + " foi criado." + " Curso: " + curso1 + ", Tipo de Disciplina: " + tipo_disciplina + ", Semestre: " + semestre + ", Creditos: " + creditos + ", Ano de Frequência: " + ano_frequencia + ".");
			Transport.send(message);
		} catch (Exception e) {
			e.printStackTrace();
		}

		RequestDispatcher rd = request.getRequestDispatcher("home");
		rd.forward(request, response);

	}

	protected void insertDisc011(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ArrayList<Curso> selectCurso = dao.listCurso();

		request.setAttribute("curso", selectCurso);
		RequestDispatcher rd = request.getRequestDispatcher("insert-disciplina.jsp");
		rd.forward(request, response);

	}

	protected void insertDisc022(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ArrayList<Curso> selectCurso = dao.listCurso();

		request.setAttribute("curso", selectCurso);
		RequestDispatcher rd = request.getRequestDispatcher("insert-disciplina1.jsp");
		rd.forward(request, response);

	}

	protected void selectCurso1(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ArrayList<Curso> selectCurso = dao.listCurso();

		request.setAttribute("curso", selectCurso);
		RequestDispatcher rd = request.getRequestDispatcher("select-curso.jsp");
		rd.forward(request, response);

	}

	protected void selectCurso2(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ArrayList<Curso> selectCurso = dao.listCurso();

		request.setAttribute("curso", selectCurso);
		RequestDispatcher rd = request.getRequestDispatcher("select-curso1.jsp");
		rd.forward(request, response);
	}

	protected void deleteCurso10(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String codigo_curso = request.getParameter("codigo_curso");
		curso.setCodigo_curso(codigo_curso);
		dao.deletarCurso1(curso);
		dao.deletarCurso2(curso);
		dao.deletarCurso(curso);
		response.sendRedirect("gerir-curso");
	}

	protected void updateCurso1(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		curso.setNome(request.getParameter("nome"));
		curso.setGrau_academico(request.getParameter("grau_academico"));
		curso.setDuracao(request.getParameter("duracao"));
		faculdade.setCodigo_faculdade(request.getParameter("codigo_faculdade"));
		curso.setFaculdade(faculdade);
		dao.alterarCurso(curso);
		response.sendRedirect("gerir-curso");
	}

	protected void AlterarPlan(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		plano_analitico.setSemana(request.getParameter("codigo_plano_analitico"));
		plano_analitico.setSemana(request.getParameter("semana"));
		plano_analitico.setConteudo(request.getParameter("conteudo"));
		plano_analitico.setObjectivos(request.getParameter("objectivos"));
		plano_analitico.setActividades(request.getParameter("actividades"));
		plano_analitico.setBibliografia(request.getParameter("bibliografia"));
		dao.alterarPLanoAnaltico(plano_analitico);
		dao.selecionarPlano_Analitico(plano_analitico);
		request.setAttribute("codigo_disciplina", plano_analitico.getDisciplina().getCodigo_disciplina());
		response.sendRedirect("verPlan?codigo_disciplina=" + plano_analitico.getDisciplina().getCodigo_disciplina());
	}

	protected void AlterarPlan1(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		plano_analitico.setSemana(request.getParameter("codigo_plano_analitico"));
		plano_analitico.setSemana(request.getParameter("semana"));
		plano_analitico.setConteudo(request.getParameter("conteudo"));
		plano_analitico.setObjectivos(request.getParameter("objectivos"));
		plano_analitico.setActividades(request.getParameter("actividades"));
		plano_analitico.setBibliografia(request.getParameter("bibliografia"));
		dao.alterarPLanoAnaltico(plano_analitico);
		dao.selecionarPlano_Analitico(plano_analitico);
		request.setAttribute("codigo_disciplina", plano_analitico.getDisciplina().getCodigo_disciplina());
		response.sendRedirect("verPlano?codigo_disciplina=" + plano_analitico.getDisciplina().getCodigo_disciplina());
	}

	protected void selectCurso11(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String codigo_curso = request.getParameter("codigo_curso");
		curso.setCodigo_curso(codigo_curso);
		dao.selecionarCurso(curso);
		request.setAttribute("codigo_curso", curso.getCodigo_curso());
		request.setAttribute("nome", curso.getNome());
		request.setAttribute("grau_academico", curso.getGrau_academico());
		request.setAttribute("duracao", curso.getDuracao());
		RequestDispatcher rd = request.getRequestDispatcher("editar-curso.jsp");
		rd.forward(request, response);
	}

	protected void curso1(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ArrayList<Curso> selectCurso = dao.listCurso();

		request.setAttribute("curso", selectCurso);
		RequestDispatcher rd = request.getRequestDispatcher("insert-curso.jsp");
		rd.forward(request, response);
	}

	protected void removerFaculdade(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String codigo_faculdade = request.getParameter("codigo_faculdade");
		faculdade.setCodigo_faculdade(codigo_faculdade);
		dao.deletarFaculdade1(faculdade);
		dao.deletarFaculdade2(faculdade);
		dao.deletarFaculdade3(faculdade);
		dao.deletarFaculdade(faculdade);
		response.sendRedirect("gerir-faculdade");
		System.out.println(codigo_faculdade);
	}

	protected void EditarFaculdade(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		faculdade.setNome(request.getParameter("nome"));
		faculdade.setEmail(request.getParameter("email"));
		faculdade.setEndereco(request.getParameter("endereco"));
		faculdade.setCidade(request.getParameter("cidade"));
		faculdade.setTelefone(request.getParameter("telefone"));
		faculdade.setFax(request.getParameter("fax"));
		dao.alterarFaculdade(faculdade);
		response.sendRedirect("gerir-faculdade");
	}

	protected void insertFaculdade(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		faculdade.setNome(request.getParameter("nome"));
		faculdade.setEmail(request.getParameter("email"));
		faculdade.setEndereco(request.getParameter("endereco"));
		faculdade.setCidade(request.getParameter("cidade"));
		faculdade.setTelefone(request.getParameter("telefone"));
		faculdade.setFax(request.getParameter("fax"));
		dao.insertFaculdade(faculdade);
		response.sendRedirect("gerir-faculdade");
	}

	protected void seleccionarFaculdade(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String codigo_faculdade = request.getParameter("codigo_faculdade");
		faculdade.setCodigo_faculdade(codigo_faculdade);
		dao.selecionarFaculdade(faculdade);
		request.setAttribute("codigo_faculdade", faculdade.getCodigo_faculdade());
		request.setAttribute("nome", faculdade.getNome());
		request.setAttribute("email", faculdade.getEmail());
		request.setAttribute("endereco", faculdade.getEndereco());
		request.setAttribute("cidade", faculdade.getCidade());
		request.setAttribute("telefone", faculdade.getTelefone());
		request.setAttribute("fax", faculdade.getFax());
		RequestDispatcher rd = request.getRequestDispatcher("editar-faculdade.jsp");
		rd.forward(request, response);
	}

	protected void insertCurso(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		curso.setNome(request.getParameter("nome"));
		curso.setGrau_academico(request.getParameter("grau_academico"));
		curso.setDuracao(request.getParameter("duracao"));
		faculdade.setCodigo_faculdade(request.getParameter("codigo_faculdade"));
		curso.setFaculdade(faculdade);
		dao.inserirCurso(curso);
		response.sendRedirect("gerir-curso");
	}

	protected void inserirFaculdade(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.sendRedirect("insert-faculdade.jsp");
	}

	protected void faculdade1(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ArrayList<Faculdade> selectFaculdade = dao.listFaculdade();

		request.setAttribute("faculdade", selectFaculdade);
		RequestDispatcher rd = request.getRequestDispatcher("buscar-faculdade.jsp");
		rd.forward(request, response);
	}

	protected void SearchPl1(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ArrayList<Disciplina> listDisciplina = dao.listDisciplina();

		request.setAttribute("disciplina", listDisciplina);
		RequestDispatcher rd = request.getRequestDispatcher("searchPlano.jsp");
		rd.forward(request, response);
	}

	protected void alterarSenha(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		usuario.setCodigo_usuario(request.getParameter("codigo_usuario"));
		usuario.setSenha(request.getParameter("senha"));
		dao.alterarSenha(usuario);
		response.sendRedirect("index.jsp");
	}

	protected void alterarSenha1(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		usuario.setCodigo_usuario(request.getParameter("codigo_usuario"));
		usuario.setSenha(request.getParameter("senha"));
		dao.alterarSenha(usuario);
		response.sendRedirect("index.jsp");
	}

	protected void SelectionDisciplina0003(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String codigo_disciplina = request.getParameter("codigo_disciplina");
		disciplina.setCodigo_disciplina(codigo_disciplina);
		dao.selecionarDisciplina(disciplina);

		request.setAttribute("codigo_disciplina", disciplina.getCodigo_disciplina());
		request.setAttribute("nome", disciplina.getNome());
		request.setAttribute("tipo_disciplina", disciplina.getTipo_disciplina());
		request.setAttribute("semestre", disciplina.getSemestre());
		request.setAttribute("creditos", disciplina.getCreditos());
		request.setAttribute("ano_frequencia", disciplina.getAno_frequencia());
		request.setAttribute("objectivos_disciplina", disciplina.getObjectivos_disciplina());

		RequestDispatcher rd = request.getRequestDispatcher("editarDisc1.jsp");
		rd.forward(request, response);

	}

	protected void EditarDisciplina(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		disciplina.setCodigo_disciplina(request.getParameter("codigo_disciplina"));
		disciplina.setNome(request.getParameter("nome"));
		disciplina.setTipo_disciplina(request.getParameter("tipo_disciplina"));
		disciplina.setSemestre(request.getParameter("semestre"));
		disciplina.setCreditos(request.getParameter("creditos"));
		disciplina.setObjectivos_disciplina(request.getParameter("objectivos_disciplina"));
		dao.alterarDisciplina(disciplina);

		response.sendRedirect("home");

	}

	protected void seleccionarDisciplina002(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String codigo_disciplina = request.getParameter("codigo_disciplina");
		disciplina.setCodigo_disciplina(codigo_disciplina);
		dao.selecionarDisciplina(disciplina);

		request.setAttribute("codigo_disciplina", disciplina.getCodigo_disciplina());
		request.setAttribute("nome", disciplina.getNome());
		request.setAttribute("tipo_disciplina", disciplina.getTipo_disciplina());
		request.setAttribute("semestre", disciplina.getSemestre());
		request.setAttribute("creditos", disciplina.getCreditos());
		request.setAttribute("ano_frequencia", disciplina.getAno_frequencia());
		request.setAttribute("objectivos_disciplina", disciplina.getObjectivos_disciplina());

		RequestDispatcher rd = request.getRequestDispatcher("editarDisc.jsp");
		rd.forward(request, response);
	}

	protected void seleccionarPlano(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String codigo_plano_analitico = request.getParameter("codigo_plano_analitico");
		plano_analitico.setCodigo_plano_analitico(codigo_plano_analitico);
		dao.selecionarPlano_Analitico(plano_analitico);

		request.setAttribute("codigo_plano_analitico", plano_analitico.getCodigo_plano_analitico());
		request.setAttribute("semana", plano_analitico.getSemana());
		request.setAttribute("conteudo", plano_analitico.getConteudo());
		request.setAttribute("objectivos", plano_analitico.getObjectivos());
		request.setAttribute("actividades", plano_analitico.getActividades());
		request.setAttribute("bibliografia", plano_analitico.getBibliografia());

		RequestDispatcher rd = request.getRequestDispatcher("editPlan.jsp");
		rd.forward(request, response);
	}

	protected void seleccionarPlano9(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String codigo_plano_analitico = request.getParameter("codigo_plano_analitico");
		plano_analitico.setCodigo_plano_analitico(codigo_plano_analitico);
		dao.selecionarPlano_Analitico(plano_analitico);

		request.setAttribute("codigo_plano_analitico", plano_analitico.getCodigo_plano_analitico());
		request.setAttribute("semana", plano_analitico.getSemana());
		request.setAttribute("conteudo", plano_analitico.getConteudo());
		request.setAttribute("objectivos", plano_analitico.getObjectivos());
		request.setAttribute("actividades", plano_analitico.getActividades());
		request.setAttribute("bibliografia", plano_analitico.getBibliografia());

		RequestDispatcher rd = request.getRequestDispatcher("editPlan1.jsp");
		rd.forward(request, response);
	}

	protected void EditarDisciplina009(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		disciplina.setCodigo_disciplina(request.getParameter("codigo_disciplina"));
		disciplina.setNome(request.getParameter("nome"));
		disciplina.setTipo_disciplina(request.getParameter("tipo_disciplina"));
		disciplina.setSemestre(request.getParameter("semestre"));
		disciplina.setCreditos(request.getParameter("creditos"));
		disciplina.setAno_frequencia(request.getParameter("ano_frequencia"));
		disciplina.setObjectivos_disciplina(request.getParameter("objectivos_disciplina"));
		dao.alterarDisciplina(disciplina);
		response.sendRedirect("admin-gerir-plan");

	}

	// Gerar Relatorio em PDF
	protected void gerarPlano(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		Document documento = new Document();

		try {
			String codigo_disciplina = request.getParameter("codigo_disciplina");
			disciplina.setCodigo_disciplina(codigo_disciplina);
			dao.gerarPlano(faculdade, curso, disciplina, usuario);
			plano_analitico.setDisciplina(disciplina);
			dao.listPlano_Analitico(plano_analitico);

			dao.listPlano_Analitico(plano_analitico);

			response.setContentType("apllication/pdf");
			// Nome do documento
			response.addHeader("Content-Disposition",
					"inline; filename=" + "Plano Analítico de " + disciplina.getNome() + ".pdf");

			// Criar novo plano

			PdfWriter.getInstance(documento, response.getOutputStream());

			// Abrir o documento

			documento.open();

			Paragraph par1 = new Paragraph();
			Font titulo1 = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD, BaseColor.BLACK);

			Image image = Image
					.getInstance("C:\\Users\\Lut Jalilo\\eclipse-workspace\\analyticalplan\\src\\main\\webapp\\img\\ucm5.png");
			image.scaleAbsolute(500, 90);
			documento.add(image);
			par1.add(new Paragraph("Universidade Católica de Moçambique", titulo1));
			par1.add(new Paragraph(faculdade.getNome(), titulo1));
			par1.add(new Paragraph("Plano Analítico - " + disciplina.getSemestre(), titulo1));
			par1.setAlignment(Element.ALIGN_CENTER);
			par1.add(new Phrase(Chunk.NEWLINE));
			documento.add(par1);

			Paragraph par2 = new Paragraph();
			Font titulo = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD, BaseColor.BLACK);
			PdfPTable tabela1 = new PdfPTable(2);

			PdfPCell col1 = new PdfPCell(new Paragraph("Curso", titulo));
			PdfPCell col2 = new PdfPCell(new Paragraph(curso.getNome()));

			PdfPCell col3 = new PdfPCell(new Paragraph("Nome da cadeira", titulo));
			PdfPCell col4 = new PdfPCell(new Paragraph(disciplina.getNome()));

			PdfPCell col5 = new PdfPCell(new Paragraph("Código", titulo));
			PdfPCell col6 = new PdfPCell(new Paragraph(disciplina.getCodigo_disciplina()));

			PdfPCell col7 = new PdfPCell(new Paragraph("Tipo de Disciplina", titulo));
			PdfPCell col8 = new PdfPCell(new Paragraph(disciplina.getTipo_disciplina()));

			PdfPCell col9 = new PdfPCell(new Paragraph("Grau Acadêmico ", titulo));
			PdfPCell col10 = new PdfPCell(new Paragraph(curso.getGrau_academico()));

			PdfPCell col11 = new PdfPCell(new Paragraph("Ano de frequência", titulo));
			PdfPCell col12 = new PdfPCell(new Paragraph(disciplina.getAno_frequencia()));

			PdfPCell col13 = new PdfPCell(new Paragraph("Semestre", titulo));
			PdfPCell col14 = new PdfPCell(new Paragraph(disciplina.getSemestre()));

			PdfPCell col15 = new PdfPCell(new Paragraph("Número de créditos Académicos", titulo));
			PdfPCell col16 = new PdfPCell(new Paragraph(disciplina.getCreditos()));

			PdfPCell col17 = new PdfPCell(new Paragraph("Docente", titulo));
			PdfPCell col18 = new PdfPCell(new Paragraph(usuario.getNome()));

			PdfPCell col19 = new PdfPCell(new Paragraph("Contacto", titulo));
			PdfPCell col20 = new PdfPCell(new Paragraph(usuario.getTelefone()));

			PdfPCell col21 = new PdfPCell(new Paragraph("E-mail", titulo));
			PdfPCell col22 = new PdfPCell(new Paragraph(usuario.getEmail()));

			PdfPCell col23 = new PdfPCell(new Paragraph("Objectivos da Disciplina", titulo));
			PdfPCell col24 = new PdfPCell(new Paragraph(disciplina.getObjectivos_disciplina()));

			tabela1.setWidthPercentage(92.5f);
			tabela1.setWidthPercentage(92.5f);
			tabela1.setWidthPercentage(92.5f);
			tabela1.setWidthPercentage(92.5f);
			tabela1.setWidthPercentage(92.5f);
			tabela1.setWidthPercentage(92.5f);
			tabela1.setWidthPercentage(92.5f);
			tabela1.setWidthPercentage(92.5f);
			tabela1.setWidthPercentage(92.5f);
			tabela1.setWidthPercentage(92.5f);
			tabela1.setWidthPercentage(92.5f);
			tabela1.setWidthPercentage(92.5f);
			tabela1.setWidthPercentage(92.5f);
			tabela1.setWidthPercentage(92.5f);
			tabela1.setWidthPercentage(92.5f);
			tabela1.setWidthPercentage(92.5f);
			tabela1.setWidthPercentage(92.5f);
			tabela1.setWidthPercentage(92.5f);
			tabela1.setWidthPercentage(92.5f);
			tabela1.setWidthPercentage(92.5f);
			tabela1.setWidthPercentage(92.5f);
			tabela1.setWidthPercentage(92.5f);
			tabela1.setWidthPercentage(92.5f);
			tabela1.setWidthPercentage(92.5f);

			tabela1.addCell(col1);
			tabela1.addCell(col2);
			tabela1.addCell(col3);
			tabela1.addCell(col4);
			tabela1.addCell(col5);
			tabela1.addCell(col6);
			tabela1.addCell(col7);
			tabela1.addCell(col8);
			tabela1.addCell(col9);
			tabela1.addCell(col10);
			tabela1.addCell(col11);
			tabela1.addCell(col12);
			tabela1.addCell(col13);
			tabela1.addCell(col14);
			tabela1.addCell(col15);
			tabela1.addCell(col16);
			tabela1.addCell(col17);
			tabela1.addCell(col18);
			tabela1.addCell(col19);
			tabela1.addCell(col20);
			tabela1.addCell(col21);
			tabela1.addCell(col22);
			tabela1.addCell(col23);
			tabela1.addCell(col24);
			documento.add(tabela1);

			documento.add(new Paragraph(" "));
			documento.add(new Paragraph(" "));
			//
			PdfPTable tabela2 = new PdfPTable(5);

			// Cabecalho
			PdfPCell col25 = new PdfPCell(new Paragraph("Semana", titulo));
			PdfPCell col26 = new PdfPCell(new Paragraph("Conteúdo", titulo));
			PdfPCell col27 = new PdfPCell(new Paragraph("Objectivos (o que se espera que se aprenda)", titulo));
			PdfPCell col28 = new PdfPCell(new Paragraph("Actividades extra-sala de aulas", titulo));
			PdfPCell col29 = new PdfPCell(new Paragraph("Bibliografia", titulo));

			tabela2.setWidthPercentage(95);
			tabela2.setWidthPercentage(95);
			tabela2.setWidthPercentage(95);
			tabela2.setWidthPercentage(95);
			tabela2.setWidthPercentage(95);

			tabela2.addCell(col25);
			tabela2.addCell(col26);
			tabela2.addCell(col27);
			tabela2.addCell(col28);
			tabela2.addCell(col29);

			ArrayList<Plano_Analitico> listPlano = dao.listPlano_Analitico(plano_analitico);
			for (int i = 0; i < listPlano.size(); i++) {
				tabela2.addCell(listPlano.get(i).getSemana());
				tabela2.addCell(listPlano.get(i).getConteudo());
				tabela2.addCell(listPlano.get(i).getObjectivos());
				tabela2.addCell(listPlano.get(i).getActividades());
				tabela2.addCell(listPlano.get(i).getBibliografia());
			}

			documento.add(tabela2);

			documento.add(new Paragraph(" "));
			documento.add(new Paragraph(" "));

			SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			String formattedDate = df.format(new Date());

			Paragraph par3 = new Paragraph();
			par3.add(new Paragraph("Data: " + formattedDate));
			par3.setAlignment(Element.ALIGN_CENTER);
			par3.add(new Paragraph(""));
			par3.add(new Paragraph(""));
			par3.add(new Paragraph(
					"     Assinatura do Docente                 Assinatura do Coordenador                 Assinatura do DAP"));
			par3.add(new Paragraph(""));
			par3.add(new Paragraph(
					"    ____________________                ____________________               ____________________ "));

			documento.add(par2);
			documento.add(par3);
			documento.close();

		} catch (Exception e) {
			e.printStackTrace();
			documento.close();
		}

	}

	protected void exit(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		session.invalidate();
		response.sendRedirect("index.jsp");
	}

	protected void control(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ArrayList<Disciplina> listDisciplina = dao.listDisciplina();
		request.setAttribute("disciplina", listDisciplina);
		RequestDispatcher rd = request.getRequestDispatcher("painel.jsp");
		rd.forward(request, response);
	}

	protected void VerPlano1(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String codigo_disciplina = request.getParameter("codigo_disciplina");
		disciplina.setCodigo_disciplina(codigo_disciplina);
		plano_analitico.setDisciplina(disciplina);
		dao.selecionarDisciplina(disciplina);
		dao.listPlano_Analitico(plano_analitico);

		ArrayList<Plano_Analitico> listPlano_Analitico = dao.listPlano_Analitico(plano_analitico);

		request.setAttribute("plano_analitico", listPlano_Analitico);
		request.setAttribute("codigo_disciplina", codigo_disciplina);
		request.setAttribute("nome", disciplina.getNome());
		RequestDispatcher rd = request.getRequestDispatcher("visualizarPlano.jsp");
		rd.forward(request, response);
	}

	protected void VerPlano100(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String codigo_disciplina = request.getParameter("codigo_disciplina");
		disciplina.setCodigo_disciplina(codigo_disciplina);
		plano_analitico.setDisciplina(disciplina);
		dao.selecionarDisciplina(disciplina);
		dao.listPlano_Analitico(plano_analitico);

		ArrayList<Plano_Analitico> listPlano_Analitico = dao.listPlano_Analitico(plano_analitico);

		request.setAttribute("plano_analitico", listPlano_Analitico);
		request.setAttribute("codigo_disciplina", codigo_disciplina);
		request.setAttribute("nome", disciplina.getNome());
		RequestDispatcher rd = request.getRequestDispatcher("verPlan.jsp");
		rd.forward(request, response);
	}

	protected void Login(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String email = request.getParameter("email");
		String senha = request.getParameter("senha");

		usuario.setEmail(email);
		usuario.setSenha(senha);

		try {
			String validarLogin = dao.validarLogin(usuario);

			if (validarLogin.equals("Administrador")) {
				session = request.getSession();
				session.setAttribute("Admin", usuario);
				session.setMaxInactiveInterval(1800);
				request.setAttribute("email", email);
				response.sendRedirect("painel");

			} else if (validarLogin.equals("Teacher")) {
				session = request.getSession();
				session.setAttribute("Usuário", usuario);
				session.setMaxInactiveInterval(1800);
				request.setAttribute("email", email);
				response.sendRedirect("home");

			} else {
				request.setAttribute("sms", validarLogin);
				request.getRequestDispatcher("index.jsp").forward(request, response);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	protected void seleccionarFaculdade00(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ArrayList<Faculdade> selectFaculdade = dao.listFaculdade();

		request.setAttribute("faculdade", selectFaculdade);
		RequestDispatcher rd = request.getRequestDispatcher("select-faculdade.jsp");
		rd.forward(request, response);
	}

	protected void adminGerirCreatePlan3(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		plano_analitico.setSemana(request.getParameter("semana"));
		plano_analitico.setConteudo(request.getParameter("conteudo"));
		plano_analitico.setObjectivos(request.getParameter("objectivos"));
		plano_analitico.setActividades(request.getParameter("actividades"));
		plano_analitico.setBibliografia(request.getParameter("bibliografia"));
		disciplina.setCodigo_disciplina(request.getParameter("codigo_disciplina"));
		plano_analitico.setDisciplina(disciplina);
		dao.inserirPlano_Analitico(plano_analitico);
		response.sendRedirect("verPlan?codigo_disciplina=" + disciplina.getCodigo_disciplina());

	}

	protected void CreatePlan3(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		plano_analitico.setSemana(request.getParameter("semana"));
		plano_analitico.setConteudo(request.getParameter("conteudo"));
		plano_analitico.setObjectivos(request.getParameter("objectivos"));
		plano_analitico.setActividades(request.getParameter("actividades"));
		plano_analitico.setBibliografia(request.getParameter("bibliografia"));
		disciplina.setCodigo_disciplina(request.getParameter("codigo_disciplina"));
		plano_analitico.setDisciplina(disciplina);
		dao.inserirPlano_Analitico(plano_analitico);
		response.sendRedirect("verPlano?codigo_disciplina=" + disciplina.getCodigo_disciplina());
	}

	protected void adminGerirUser(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ArrayList<Usuario> list = dao.listUsuario();
		ArrayList<Disciplina> listDisciplina = dao.listDisciplina();
		request.setAttribute("usuario1", list);
		request.setAttribute("disciplina", listDisciplina);
		RequestDispatcher rd = request.getRequestDispatcher("gerir-user.jsp");
		rd.forward(request, response);
	}

	protected void adminGerirFaculdade(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ArrayList<Faculdade> listFaculdade = dao.listFaculdade();
		ArrayList<Disciplina> listDisciplina = dao.listDisciplina();

		request.setAttribute("disciplina", listDisciplina);
		request.setAttribute("faculdade", listFaculdade);
		RequestDispatcher rd = request.getRequestDispatcher("gerir-faculdade.jsp");
		rd.forward(request, response);
	}

	protected void adminGerirCurso(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ArrayList<Curso> listCurso = dao.listCurso();
		ArrayList<Disciplina> listDisciplina = dao.listDisciplina();

		request.setAttribute("disciplina", listDisciplina);
		request.setAttribute("curso", listCurso);
		RequestDispatcher rd = request.getRequestDispatcher("gerir-curso.jsp");
		rd.forward(request, response);
	}

	protected void adminGerirPlan2(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		ArrayList<Plano_Analitico> listPlano_Analitico = dao.listPlano_Analitico(plano_analitico);

		request.setAttribute("plano_analitico", listPlano_Analitico);
		RequestDispatcher rd = request.getRequestDispatcher("gerir-plan.jsp");
		rd.forward(request, response);

	}

	protected void adminGerirPlan(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ArrayList<Disciplina> listDisciplina = dao.listDisciplina();

		request.setAttribute("disciplina", listDisciplina);
		RequestDispatcher rd = request.getRequestDispatcher("gerir-plan.jsp");
		rd.forward(request, response);

	}

	protected void adminGerirCreateUser(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.sendRedirect("create-user.jsp");

	}

	protected void adminCreateUser(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.sendRedirect("create-user.jsp");

	}

	protected void adminRedefinirSenha(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.sendRedirect("enviar-email.jsp");

	}

	protected void RedefinirSenha1(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.sendRedirect("enviar-email.jsp");

	}

	protected void userPaginaInicial(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		ArrayList<Disciplina> listDisciplina = dao.listDisciplina1(disciplina, usuario);
		request.setAttribute("disciplina", listDisciplina);
		RequestDispatcher rd = request.getRequestDispatcher("home.jsp");
		rd.forward(request, response);

	}

	protected void userGerirPlan(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		ArrayList<Disciplina> listDisciplina1 = dao.listDisciplina();

		request.setAttribute("disciplina", listDisciplina1);
		RequestDispatcher rd = request.getRequestDispatcher("gerir-plan.jsp");
		rd.forward(request, response);

	}

	protected void userRedefinirSenha(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.sendRedirect("enviar-email.jsp");

	}

	protected void seleccionarFaculdade01(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ArrayList<Faculdade> selectFaculdade = dao.listFaculdade();

		request.setAttribute("faculdade", selectFaculdade);
		RequestDispatcher rd = request.getRequestDispatcher("select-faculdade1.jsp");
		rd.forward(request, response);

	}

	protected void CreateUser1(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		usuario.setNome(request.getParameter("nome"));
		usuario.setEmail(request.getParameter("email"));
		usuario.setGenero(request.getParameter("genero"));
		usuario.setSenha(request.getParameter("senha"));
		usuario.setTipo(request.getParameter("tipo"));
		usuario.setTelefone(request.getParameter("telefone"));
		usuario.setCidade(request.getParameter("cidade"));
		usuario.setEndereco(request.getParameter("endereco"));
		dao.criarUsuario(usuario);

		response.sendRedirect("index.jsp");
	}

	protected void removerUser(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String codigo_usuario = request.getParameter("codigo_usuario");
		usuario.setCodigo_usuario(codigo_usuario);
		dao.deletarUtilizador1(usuario);
		dao.deletarUtilizador2(usuario);
		dao.deletarUtilizador(usuario);
		response.sendRedirect("admin-gerir-user");
	}

	protected void removerPlan(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String codigo_disciplina = request.getParameter("codigo_disciplina");
		disciplina.setCodigo_disciplina(codigo_disciplina);
		dao.deletarDisciplina(disciplina);
		dao.deletarDisciplina2(disciplina);
		response.sendRedirect("admin-gerir-plan");
	}

	protected void ExcluirPlano(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String codigo_plano_analitico = request.getParameter("codigo_plano_analitico");
		plano_analitico.setCodigo_plano_analitico(codigo_plano_analitico);
		disciplina.setCodigo_disciplina(request.getParameter("codigo_disciplina"));
		plano_analitico.setDisciplina(disciplina);
		dao.selecionarPlano_Analitico(plano_analitico);
		request.setAttribute("codigo_disciplina", plano_analitico.getDisciplina().getCodigo_disciplina());
		dao.deletarPlano_Analitico(plano_analitico);
		response.sendRedirect("verPlan?codigo_disciplina=" + plano_analitico.getDisciplina().getCodigo_disciplina());
	}

	protected void ExcluirPlano1(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String codigo_plano_analitico = request.getParameter("codigo_plano_analitico");
		plano_analitico.setCodigo_plano_analitico(codigo_plano_analitico);
		disciplina.setCodigo_disciplina(request.getParameter("codigo_disciplina"));
		plano_analitico.setDisciplina(disciplina);
		dao.selecionarPlano_Analitico(plano_analitico);
		request.setAttribute("codigo_disciplina", plano_analitico.getDisciplina().getCodigo_disciplina());
		dao.deletarPlano_Analitico(plano_analitico);
		response.sendRedirect("verPlano?codigo_disciplina=" + plano_analitico.getDisciplina().getCodigo_disciplina());
	}

	protected void removerPlan1(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String codigo_disciplina = request.getParameter("codigo_disciplina");
		disciplina.setCodigo_disciplina(codigo_disciplina);
		dao.deletarDisciplina(disciplina);
		dao.deletarDisciplina2(disciplina);
		response.sendRedirect("home");
	}

	protected void seleccionarUser(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String codigo_usuario = request.getParameter("codigo_usuario");
		usuario.setCodigo_usuario(codigo_usuario);
		dao.selecionarUsuario1(usuario);
		request.setAttribute("codigo_usuario", usuario.getCodigo_usuario());
		request.setAttribute("nome", usuario.getNome());
		request.setAttribute("email", usuario.getEmail());
		request.setAttribute("genero", usuario.getGenero());
		request.setAttribute("senha", usuario.getSenha());
		request.setAttribute("tipo", usuario.getTipo());
		request.setAttribute("telefone", usuario.getTelefone());
		request.setAttribute("cidade", usuario.getCidade());
		request.setAttribute("endereco", usuario.getEndereco());
		RequestDispatcher rd = request.getRequestDispatcher("editarUtilizador.jsp");
		rd.forward(request, response);
	}

	protected void updateUser11(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		usuario.setCodigo_usuario(request.getParameter("codigo_usuario"));
		usuario.setNome(request.getParameter("nome"));
		usuario.setEmail(request.getParameter("email"));
		usuario.setGenero(request.getParameter("genero"));
		usuario.setSenha(request.getParameter("senha"));
		usuario.setTipo(request.getParameter("tipo"));
		usuario.setTelefone(request.getParameter("telefone"));
		usuario.setCidade(request.getParameter("cidade"));
		usuario.setEndereco(request.getParameter("endereco"));
		dao.alterarUsuario(usuario);
		response.sendRedirect("admin-gerir-user");
	}

}